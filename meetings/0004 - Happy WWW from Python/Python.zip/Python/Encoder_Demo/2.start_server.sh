#!/bin/bash

echo 'Starting Encoder Demo web application'
echo 'Once server starts, open this web page: http://localhost:8080\n\n'

python3 server.py
