#!/bin/bash

# show encoder values on th command line
./encoder.py
