#!/usr/bin/python3

# functions to support the encoder attached to the serial port

# NOTE: the Arduino will reset every time the serial port is opened and DTR changes


# support for timing delays, etc
import time

def connect():
    # connect to the encoder 
   import serial
   ser = serial.Serial('/dev/ttyUSB0', baudrate=115200)

   # wait (2) seconds for the Arduino to reboot
   time.sleep(2)

   return ser

def read_encoder(ser):
    # read the current position of the encoder

    # clear the serial port buffer
    ser.flush()

    # send the position command
    ser.write(b"p\r")

    # wait for a response
    time.sleep(0.05)

    # default is no position read
    position=-1

    # if there are serial characters, process them 
    if (ser.inWaiting()>0):
      # read the buffer
      response = ser.read(ser.inWaiting()).decode('ascii')
      #print ("python printed:", response)

      # process if there is a position
      if ("[" in response):
        bits=response.split("[") 
        bits=bits[1].split("]")
        position=int(bits[0])
      else:
        print ("ERROR: no position found.")
      return position

if __name__=="__main__":
    # demo of using this library
    print ("ENCODER COMMAND LINE DEMO")
    print ("A demo of reading the encoder from the attached Arduino Nano")
    print ("\n")
    # connect to the serial port 
    ser=connect()

    # continously poll the encoder
    while 1:
         pos=read_encoder(ser)
         print ("Position=%s"%(pos))
         time.sleep(0.1)

