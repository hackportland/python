#!/usr/bin/python3

from bottle import route, run, static_file

# support for serially connected encoder
import encoder

# support for ip address discovery
import ifaddr


# the serial connection for the encoder
ser=encoder.connect()

# the default encoder web page
@route('/')
def index():
   # the default web page

   # NOTE: need jquery to support gauge canvas
    
   pg="""
     <html>
       <head>
         <title>ENCODER STATUS</title>
         <script type="text/javascript" src="jquery-3.3.1.min.js"></script>
         <script type="text/javascript" src="gauge.min.js"></script>   
       </head>

      <body>
        <b>ENCODER GAUGE DEMO</b> <br/>
        <br/>

<!-- Injecting radial gauge -->
<canvas id="encoder_gauge"
        data-type="radial-gauge"
        data-width="400"
        data-height="400"
        data-units="Gigawatts"
        data-title="false"
        data-value="0"
        data-min-value="0"
        data-max-value="220"
        data-major-ticks="0,20,40,60,80,100,120,140,160,180,200,220"
        data-minor-ticks="2"
        data-stroke-ticks="false"
        data-highlights='[
            { "from": 0, "to": 50, "color": "rgba(0,255,0,.15)" },
            { "from": 50, "to": 100, "color": "rgba(255,255,0,.15)" },
            { "from": 100, "to": 150, "color": "rgba(255,30,0,.25)" },
            { "from": 150, "to": 200, "color": "rgba(255,0,225,.25)" },
            { "from": 200, "to": 220, "color": "rgba(0,0,255,.25)" }
        ]'
        data-color-plate="#222"
        data-color-major-ticks="#f5f5f5"
        data-color-minor-ticks="#ddd"
        data-color-title="#fff"
        data-color-units="#ccc"
        data-color-numbers="#eee"
        data-color-needle-start="rgba(240, 128, 128, 1)"
        data-color-needle-end="rgba(255, 160, 122, .9)"
        data-value-box="true"
        data-animation-rule="bounce"
        data-animation-duration="500"
        data-font-value="Led"
        data-animated-value="true"
></canvas>
<br/>
URL's: <br/> 
* gauge display: http://%s:8080<br/>
* value display: http://%s:8080/encoder_position<br>

 <script>
    setInterval(function()
{
    $.ajax({
        type: "get",
        url: "/encoder_position",
        success:function(data)
        {
            //console.log the response
            console.log(data);

            // update the gauge
            //encoder_gauge.data_value = 10;
            encoder_gauge.setAttribute('data-value',data);
        }
    });
}, 200); //200 milliseconds = 0.2 seconds

    </script>
  </body>
 </html>
   """%(server_ip_address, server_ip_address)
   return pg



@route('/encoder_position')
def encoder_position():
    # read and return the encoder value
    
    # read the position from the serial port
    pos=encoder.read_encoder(ser)

    # scale the position for display, etc
    scaled_pos=int(pos*10)

    return "%s"%(scaled_pos)


# static files
@route('<path:path>')
def server_static(path):
    # serve files out of the script's current directory
    import os
    dir_path = os.path.dirname(os.path.realpath(__file__))
    return static_file(path, root=dir_path)

# get information for this server
adapters = ifaddr.get_adapters()
server_ip_address=None
for adapter in adapters:
    # chose the first wireless adapter 
    if 'wlp' in adapter.nice_name:
        server_ip_address=adapter.ips[0].ip

# set to '0.0.0.0' to listen for all hosts
run(host='0.0.0.0', port=8080, debug=True)
