#!/usr/bin/python3

# a demo of retrieving stock info for a given company

# use the Yahoo Finance driver
import driver_yahoo as stock_driver

# supports stock related functions
import stock_utils

# update user
print ("STOCK INFO DEMO")
print ("\n")

# a simple list
stock_list=["AAPL",]

# retrieve data for this list
#print ("Updating stock info:")
s=stock_utils.get_list(stock_list,stock_driver)

# show user parameters
print ("Stock data:")
this_stock=s[0]
for k in this_stock.keys():
    print (" %s=%s"%(k,this_stock[k]))
print("")
