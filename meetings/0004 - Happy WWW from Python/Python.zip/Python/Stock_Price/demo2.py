#!/usr/bin/python3

# a demo of inspecting the Dow 


# use the Yahoo Finance driver
import driver_yahoo as stock_driver

# supports stock related functions
import stock_utils

# Dow stocks
stock_list=stock_utils.dow_stocks()

# update user
print ("DOW PERFORMANCE")
print ("\n")

# retrieve data for this list
print ("Updating stock info from the list of Dow stocks:")
s=stock_utils.get_list(stock_list,stock_driver)

# the top three stocks at closing
p1=stock_utils.sort_daily_performance(s)
print ("")
print ("=====TOP (5) PERFORMANCE=========")

for this_stock in p1[:5]:
    # {'stock_symbol': 'WMT', 'regularMarketPrice': 99.66, 'regularMarketVolume': 5382286.0, 'longName': b'Walmart Inc.', 'regularMarketChange': 1.2400055}
    print ("  %s [%s] changed %s dollars"%(this_stock['longName'].decode("utf-8"),this_stock['stock_symbol'],round(this_stock['regularMarketChange'],1)))


print ("")
print ("=====WORST (5) PERFORMANCE=========")
p1.reverse()
for this_stock in p1[:5]:
    # {'stock_symbol': 'WMT', 'regularMarketPrice': 99.66, 'regularMarketVolume': 5382286.0, 'longName': b'Walmart Inc.', 'regularMarketChange': 1.2400055}
    print ("  %s [%s] changed %s dollars "%(this_stock['longName'].decode("utf-8"),this_stock['stock_symbol'],round(this_stock['regularMarketChange'],1)))

