#!/usr/bin/python3

# a demo of inspecting Maine based commpany stock's

# use the Yahoo Finance driver
import driver_yahoo as stock_driver

# supports stock related functions
import stock_utils

# Maine stocks
stock_list=stock_utils.maine_stocks()

# update user
print ("MAINE BASED COMPANY STOCK PERFORMANCE")
print ("\n")

# retrieve data for this list
print ("Updating stock info from the list of Maine stocks:")
s=stock_utils.get_list(stock_list,stock_driver)

# the top three stocks at closing
p1=stock_utils.sort_daily_performance(s)
print ("")
print ("=====TOP PERFORMANCE=========")

for this_stock in p1:
    # {'stock_symbol': 'WMT', 'regularMarketPrice': 99.66, 'regularMarketVolume': 5382286.0, 'longName': b'Walmart Inc.', 'regularMarketChange': 1.2400055}
    print ("  %s [%s] changed %s dollars "%(this_stock['longName'].decode("utf-8"),this_stock['stock_symbol'],round(this_stock['regularMarketChange'],1)))


print ("")
print ("=====WORST PERFORMANCE=========")
p1.reverse()
for this_stock in p1:
    # {'stock_symbol': 'WMT', 'regularMarketPrice': 99.66, 'regularMarketVolume': 5382286.0, 'longName': b'Walmart Inc.', 'regularMarketChange': 1.2400055}
    print ("  %s [%s] changed %s dollars "%(this_stock['longName'].decode("utf-8"),this_stock['stock_symbol'],round(this_stock['regularMarketChange'],1)))

