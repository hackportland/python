# A stock market info model for Yahoo Finance

# supports HTTP requests, etc
import requests

def info(stock_symbol):
    # stock info for the specified symbol

    # client header
    headers = {'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36'}
    page = requests.get('https://finance.yahoo.com/quote/%s?p=%s'%(stock_symbol, stock_symbol), headers=headers)
   
    # specify encoding for page, to be used in parsing
    page.encoding = 'utf-8'
    contents = page.content

    # split up, only looking at lines with the stock symbol (eg AAPL) as an attribute (eg "AAPL": )
    search_element='"%s"'%(stock_symbol)
    bits=contents.split(bytearray(search_element,'utf-8'))


    # enable search for price in page by setting to True, to determine the location of the stock information
    if False:
     x=0
     for b in bits:
        if (b'188.02' in b):
            print (x)
            print (b[:1200])
        x=x+1

     # exit script
     import sys;sys.exit()


    # location of stock info, found after inspection for closing stock price (eg 188.02) (see above)
    stock_info_txt=bits[12]
  
    # tidy up the stream, removing extraneous info
    stock_info_txt=stock_info_txt.replace(b':{"sourceInterval":15,"',b"")
    
    # split up by elements and trim off the last two lines which are noise
    bits=stock_info_txt.split(b',')
    bits=bits[:-2]
   
    # segment more, this time split up attributes (eg :)
    bits2=[]
    for b in bits:
        b2=b.split(b":")
        bits2.extend(b2)

    # set to True to locate offset for items values. 
    if False:
     index=0
     for b in bits2:
        print (index,b)
        index=index+1
  

    # map for parsing attributes (attribute, offset from attribute occurancei, type)
    a=[]
    a.append(('regularMarketPrice',+2,'f'))
    a.append(('regularMarketVolume',+2,'f'))
    a.append(('longName',+1,'b'))
    a.append(('regularMarketChange',+2,'f'))
    this_stock_info={'stock_symbol':stock_symbol}
    for attrib in a:
        # find this attribute and its value from the specified offset
        this_offset=0
        for b in bits2:
            if bytearray('"'+attrib[0]+'"','utf-8')==b:
              location_of_value=this_offset+attrib[1]
              # save this value, stripping out any extra quotes 
              this_stock_info[attrib[0]]=bits2[location_of_value].strip(b'"')
              # save as a float, if specified
              if (attrib[2]=='f'):
                  this_stock_info[attrib[0]]=float(this_stock_info[attrib[0]])
              break
            this_offset=this_offset+1
    
    return this_stock_info


