# A stock market utilities

def dow_stocks():
    # return a list of Dow stocks

    # a list of Dow Index stocks as of 2019:
    data="""MMM
AXP
AAPL
CAT
CVX
CSCO
DWDP
XOM
INTC
IBM
JNJ
JPM
MCD
MRK
MSFT
NKE
PFE
BA
KO
GS
HD
PG
TRV
DIS
UTX
UNH
VZ
V
WBA
WMT"""
    bits=data.split("\n")
    dow_stock_list=[]
    for b in bits:
       dow_stock_list.append(b)
    return dow_stock_list


def maine_stocks():
    # return a list of stocks for companies based in Maine as of 2019
    l=["BHB","CAC","FNLC","IDXX","ICCC","NBN","WEX", "CVET"]
    return l


def get_list(stock_symbol_list, stock_driver):
    # retrieve info from a list of stocks
    stock_list=[]
    for s in stock_symbol_list:
      stock_info=stock_driver.info(s)
      stock_list.append(stock_info)
      # update the user
      print (stock_info['stock_symbol'], end=" ", flush=True)
    print()
    return stock_list

            
def sort_daily_performance(stocks):
    # return a sorted list stocks by daily performance (regularMarketChange)
    sorted=[]
    market_change=[]
    for s in stocks:
        market_change.append((s['regularMarketChange'],s))
    # sort and then reverse so list is sorted by descending performance
    market_change.sort()
    market_change.reverse()
    for m in market_change:
        sorted.append(m[1])
    return sorted
